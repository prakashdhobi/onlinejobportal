﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class Login : System.Web.UI.Page
{
    public SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-G1HVDOBG ;Initial Catalog=project11;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {

    }
   
    protected void BtnSignIn_Click(object sender, EventArgs e)
    {
        if (txtUserName.Text == "Admin" || txtPassword.Text == "@Router")
        {
            //ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Sucessfully login')</script>",);
            Response.Redirect("AdminHome.aspx");

        }
        else
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("select * from tblRegister where UserName=@username and Password=@Password", con);
            cmd.Parameters.AddWithValue("@username", txtUserName.Text);
            cmd.Parameters.AddWithValue("@Password", txtPassword.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                Session["UserName"] = dt.Rows[0][0].ToString().Trim();
                Session["Password"] = dt.Rows[0][1].ToString().Trim();
                Response.Redirect("Home.aspx?" + txtUserName.Text);
                Response.Write("<script>alert('Welcome to My site')</script>");
            }
            else
            {
                Response.Write("<script>alert('Please enter valid Username and Password')</script>");

                // ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid User Name and Password')</script>");
            }
        }

    }
    protected void btnRegistration_Click(object sender, EventArgs e)
    {
        Response.Redirect("Registration.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("ForgotPassword.aspx");
    }
    
}