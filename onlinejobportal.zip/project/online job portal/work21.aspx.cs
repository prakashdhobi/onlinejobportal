﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class work21 : System.Web.UI.Page
{

    public SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-G1HVDOBG ;Initial Catalog=project11;Integrated Security=True");

    public static string a, b, c, d, z, f, g, h, n, j, k, l, m;
  
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            getdata();

        }

    }

    public void getdata()
    {
        try
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            string s = "select JobID,JobName,AboutJob,ExperienceRequired,Qualification,Location,FunctionalArea,Salary,ContactName,ContactNumber,EmailID,Work from tblJob where  JobID='" + Session["JobID"].ToString() + "' ";
            //Where JobID='"+ Session["JobID"] +"'
            SqlCommand cmd = new SqlCommand(s, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            cmd.ExecuteNonQuery();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                DetailsView1.DataSource = dt;
                DetailsView1.DataBind();


                //DetailsView1.DataSource = dt;
                //DetailsView1.DataBind();
                //string s1 = "select JobID,JobName,AboutJob,ExperienceRequired,Qualification,Location,FunctionalArea,Salary,ContactName,ContactNumber,EmailID,Work from tblJob  where JobID=23456 ";
                ////Where JobID='"+ Session["JobID"] +"'
                //SqlCommand cmd1 = new SqlCommand(s1, con);
                //SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
                //DataTable dt1 = new DataTable();
                //cmd1.ExecuteNonQuery();
                //da1.Fill(dt1);
                //DetailsView2.DataSource = dt1;
                //DetailsView2.DataBind();
                a = dt.Rows[0]["JobID"].ToString();
                b = dt.Rows[0]["JobName"].ToString();
                c = dt.Rows[0]["AboutJob"].ToString();
                d = dt.Rows[0]["ExperienceRequired"].ToString();
                z = dt.Rows[0]["Qualification"].ToString();
                f = dt.Rows[0]["Location"].ToString();
                g = dt.Rows[0]["FunctionalArea"].ToString();
                h = dt.Rows[0]["Salary"].ToString();
                n = dt.Rows[0]["ContactName"].ToString();
                j = dt.Rows[0]["ContactNumber"].ToString();
                k = dt.Rows[0]["EmailID"].ToString();
                l = dt.Rows[0]["Work"].ToString();
                m = Session["UserName"].ToString();
            }
        }
        catch (Exception)
        {
        }
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        try
        {
            lblerror.Text = "";
            lblmsg.Text = "";
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            string s1 = "insert into tblview2(UserName,JobID,JobName,AboutJOB,Experience,Qualification,Location,FunctionalArea,Salary,ContactName,ContactNumber,EmailID,Work) values('" + m + "','" + a + "','" + b + "','" + c + "','" + d + "','" + z + "','" + f + "','" + g + "','" + h + "','" + n + "','" + j + "','" + k + "','" + l + "'  )";

            SqlCommand cmd1 = new SqlCommand(s1, con);
            int i = cmd1.ExecuteNonQuery();
            if (i > 0)
            {

                Response.Write("<script>alert('Thanks For Applying Job')</script>");
            }
            con.Close();
        }
        /* else
         {
             lblerror.Text = "Job  Not  Selected ";
         }
         con.Close();
     }*/
        catch (Exception ex)
        {
            lblerror.Text = ex.Message;
        }
    }
    protected void DetailsView1_PageIndexChanging(object sender, DetailsViewPageEventArgs e)
    {

    }
}