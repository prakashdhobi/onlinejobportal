﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class SearchJob : System.Web.UI.Page
{

    public SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-G1HVDOBG ;Initial Catalog=project11;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            getdata();
        }
    }
    public void getdata()
    {
        try
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            string s = "select JobID,JobName,Salary from tblJob";
            SqlCommand cmd = new SqlCommand(s, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            cmd.ExecuteNonQuery();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            Session["JobID"]=dt.Rows[0][0].ToString().Trim();
            //Response.Redirect("jobselect.aspx");

        }
        catch (Exception)
        {
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}