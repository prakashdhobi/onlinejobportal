﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class addjob : System.Web.UI.Page
{
    public SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-G1HVDOBG ;Initial Catalog=project11;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void BtnApply_Click(object sender, EventArgs e)
    {
         try
            {
                lblerror.Text = "";
                lblmsg.Text = "";
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                con.Open();
                string s = "insert into tblJob(JobID,JobName,AboutJOB,ExperienceRequired,Qualification,Location,FunctionalArea,Salary,ContactName,ContactNumber,EmailID,Work) values('" + txtJobID.Text.Trim() + "','" + txtJobName.Text.Trim() + "','" + txtAboutJob.Text.Trim() + "','" + txtExperience.Text.Trim() + "','" + txtQualify.Text.Trim() + "','" + txtlntJob.Text.Trim() + "','" + Dropdwnaddjob.Text.Trim() + "','" + txtSalary.Text.Trim() + "','" + txtContactprsnName.Text.Trim() + "','" + txtContactno.Text.Trim() + "','" + txtEmailId.Text.Trim() + "','" + txtWorkExpern.Text.Trim() + "'  )";
                SqlCommand cmd = new SqlCommand(s, con);
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    clear();
                    lblmsg.Text = "Regestration SuccessFully";
                }
                else
                {
                    lblerror.Text = "Regestration Not SuccessFully";
                }
                con.Close();
            }
            catch (Exception ex)
            {
                lblerror.Text = ex.Message;
            }

        }
        public void clear()
        {
            txtJobID.Text = "";
            txtJobName.Text = "";
            txtAboutJob.Text = "";
            txtExperience.Text = "";
            txtQualify.Text = "";
            txtlntJob.Text = "";
            Dropdwnaddjob.Text = "";
            txtSalary.Text = "";
            txtContactprsnName.Text = "";
            txtContactno.Text = "";
            txtEmailId.Text = "";
            txtWorkExpern.Text = "";

        
    }
}