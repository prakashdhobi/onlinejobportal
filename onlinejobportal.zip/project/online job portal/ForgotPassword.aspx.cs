﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class ForgotPassword : System.Web.UI.Page
{
    public SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-G1HVDOBG ;Initial Catalog=project11;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("select Security from tblRegister where Security=@Security", con);
        cmd.Parameters.AddWithValue("@Security", TextSecurity.Text);

        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        con.Open();
        int i = cmd.ExecuteNonQuery();
        con.Close();

        if (dt.Rows.Count > 0)
        {
            Response.Redirect("ForgotPassword1.aspx");
        }
        else
        {
            Label1.Text = "You're Security key is wrong";
            Label1.ForeColor = System.Drawing.Color.Red;

        }  
           
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }
}