﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class ForgotPassword1 : System.Web.UI.Page
{
    public SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-G1HVDOBG ;Initial Catalog=project11;Integrated Security=True");

    
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("Update tblRegister SET Password=@password,ConfrimPassword=@ConfrimPassword where UserName=@UserName ", con);
        cmd.Parameters.AddWithValue("@UserName", txtusname.Text);
        cmd.Parameters.AddWithValue("@password", txtPass.Text);
        cmd.Parameters.AddWithValue("@Confrimpassword", txtconPass.Text);

        SqlDataAdapter sda = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        con.Open();
        int i = cmd.ExecuteNonQuery();
        con.Close();

        if (dt.Rows.Count >= 0)
        {
            lbmsg.Text = "Updated your Password";
            //Response.Redirect("Home.aspx");
        }
        else
        {
            lbmsg.Text = "You're Security key is wrong";
            lbmsg.ForeColor = System.Drawing.Color.Red;

        }
        //Response.Redirect("Home.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }
}