﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class Registration : System.Web.UI.Page
{
    public SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-G1HVDOBG ;Initial Catalog=project11;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
            try
            {
                lblerror.Text = "";
                lblmsg.Text = "";
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                con.Open();
                string s = "select EmailID from tblRegister where EmailID='" + txtEmail.Text.ToString().Trim() + "'";
                SqlCommand cmd = new SqlCommand(s, con);
                SqlDataAdapter d = new SqlDataAdapter(cmd);
                DataTable q = new DataTable();
                d.Fill(q);
               
                if (q.Rows.Count >  0)
                {
                    lblerror.Text = "EmailID Already Exist ";
                }
                else
                {

                    string s1 = "insert into tblRegister(UserName,Password,ConfrimPassword,Security,[D.O.B],Gender,Address,EmailID,Country,ContactNumber) values('" + txtUserName.Text.Trim() + "','" + txtPassword.Text.Trim() + "','" + txtConfirmPassword.Text.Trim() + "','" + txtSecurity.Text.Trim() + "','" + txtDOB.Text.Trim() + "','" + rdbtnGender.Text.Trim() + "','" + txtAddress.Text.Trim() + "','" + txtEmail.Text.Trim() + "','" + txtCountry.Text.Trim() + "','" + txtContact.Text.Trim() + "')";
                    SqlCommand cmd1 = new SqlCommand(s1, con);
                    int i1 = cmd1.ExecuteNonQuery();
                    if (i1 > 0)
                    {
                        clear();

                        lblerror.Text = "Regestration  SuccessFully";
                    }
                    else
                    {
                        lblerror.Text = " Not Registred   SuccessFully";
                    }
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                lblerror.Text = ex.Message;
            }
            Response.Redirect("login.aspx");
        }
        public void clear()
        {
         
            txtUserName.Text = "";
            txtPassword.Text = "";
            txtConfirmPassword.Text = "";
            txtSecurity.Text = "";
            txtDOB.Text = " ";
            rdbtnGender.Text = "";
            txtAddress.Text = "";
            txtEmail.Text = "";
            txtCountry.Text = "";
            txtContact.Text = "";
           
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
}
