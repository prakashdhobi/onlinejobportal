﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;

public partial class adminEmail : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Send_Click(object sender, EventArgs e)
    {
    
        string body = "form:" + TextBox1.Text + "\n";
        body+= "Subject:" + TextBox4.Text + "\n";
        body += "Message:" + TextBox5.Text + "\n";
        System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient();
        {
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.EnableSsl = true;
            smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
            smtp.Credentials = new NetworkCredential(TextBox1.Text,TextBox2.Text);
            smtp.Timeout = 20000;
        }
        smtp.Send(TextBox1.Text, TextBox3.Text, TextBox5.Text,body);
        Response.Write("<script>alert('Successful send mail. ')</script>");
       // Label1.Text = "Successful send mail";
    }
}