﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class AdminDeletejob : System.Web.UI.Page
{

    //public SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-G1HVDOBG ;Initial Catalog=project11;Integrated Security=True");
    
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            //getdata();
        }

    }
    //public void getdata()
    //{
    //    try
    //    {
    //        if (con.State == ConnectionState.Open)
    //        {
    //            con.Close();
    //        }
    //        con.Open();
    //        string s = "select JobID,JobName,AboutJob,ExperienceRequired,Qualification,Location,FunctionalArea,Salary,ContactName,ContactNumber,EmailID,Work from tblJob";
    //        SqlCommand cmd = new SqlCommand(s, con);
    //        SqlDataAdapter da = new SqlDataAdapter(cmd);
    //        DataTable dt = new DataTable();
    //        cmd.ExecuteNonQuery();
    //        da.Fill(dt);
    //        D2.DataSource = dt;
    //        D2.DataBind();
    //    }
    //    catch (Exception)
    //    {
    //    }
    //}

    protected void D2_SelectedIndexChanged(object sender, EventArgs e)
    {
        //try
        //    {
        //        String abc;
        //        abc = D2.SelectedRow.Cells[0].Text;
        //        if (con.State == ConnectionState.Open)
        //        {
        //            con.Close();

        //        }
        //        con.Open();
        //        String pqr = "delete from tblJob where JobID ='" + abc + "'";
        //        SqlCommand cmd = new SqlCommand(pqr, con);
        //        int i = cmd.ExecuteNonQuery();
        //        if (i > 0)
        //        {
        //            getdata();

        //        }
        //        con.Close();
        //    }
        //    catch (Exception)
        //    {
        //    }
        }
    protected void Row_Deleting(object sender, GridViewDeleteEventArgs e)
    {

    }
}
