﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class Professional : System.Web.UI.Page
{

    public SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-G1HVDOBG ;Initial Catalog=project11;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {

    }
   
protected void  Button1_Click(object sender, EventArgs e)
{
    FileUpload1.SaveAs(Server.MapPath("Resume\\" + FileUpload1.FileName + " .docx "));

    try
    {
        lblerror.Text = "";
        lblmsg.Text = "";
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
        con.Open();
        string s = "insert into tblProfessional(Degree,Year,Percentage,University,Experience,WorkedField,KeySkills,Upload) values('" + DropDownHDA.Text.Trim() + "','" + txtYear.Text.Trim() + "','" + txtPercentage.Text.Trim() + "','" + DropDownList2.Text.Trim() + "','" + txtExperience.Text.Trim() + "','" + DropDownWork + "','" + txtKeySkill.Text.Trim() + "','" + FileUpload1 + "')";
        SqlCommand cmd = new SqlCommand(s, con);
        int i = cmd.ExecuteNonQuery();
        if (i > 0)
        {
            //clear();
            lblmsg.Text = "professional data added SuccessFully";
        }
        else
        {
            lblerror.Text = "data are not Filled correctly ";
        }
        con.Close();
    }
    catch (Exception ex)
    {
        lblerror.Text = ex.Message;
    }
    //Response.Redirect("Home.aspx");
}
//public void clear()
//{
//    txtFirstName.Text = "";
//    txtLastName.Text = "";
//    txtUserName.Text = "";
//    txtPassword.Text = "";
//    txtConfirmPassword.Text = "";
//    txtDOB.Text = " ";
//    rdbtnGender.Text = "";
//    txtAddress.Text = "";
//    txtEmail.Text = "";
//    txtCountry.Text = "";
//    txtContact.Text = "";
//}

}