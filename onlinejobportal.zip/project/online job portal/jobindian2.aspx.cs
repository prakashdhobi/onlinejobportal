﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class jobindian2 : System.Web.UI.Page
{
    public SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-G1HVDOBG ;Initial Catalog=project11;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            getdata();
        }
    }
    public void getdata()
    {
        try
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            string s = "select JobID,JobName,AboutJob,ExperienceRequired,Qualification,Location,FunctionalArea,Salary,ContactName,ContactNumber,EmailID,Work from tblJob ";
            //Where JobID='"+ Session["JobID"] +"'
            SqlCommand cmd = new SqlCommand(s, con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            cmd.ExecuteNonQuery();
            da.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();


            //DetailsView1.DataSource = dt;
            //DetailsView1.DataBind();
            //string s1 = "select JobID,JobName,AboutJob,ExperienceRequired,Qualification,Location,FunctionalArea,Salary,ContactName,ContactNumber,EmailID,Work from tblJob  where JobID=23456 ";
            ////Where JobID='"+ Session["JobID"] +"'
            //SqlCommand cmd1 = new SqlCommand(s1, con);
            //SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            //DataTable dt1 = new DataTable();
            //cmd1.ExecuteNonQuery();
            //da1.Fill(dt1);
            //DetailsView2.DataSource = dt1;
            //DetailsView2.DataBind();

        }
        catch (Exception)
        {
        }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["JobID"] = GridView1.SelectedRow.Cells[0].Text.ToString().Trim();
        Response.Redirect("jobindian3.aspx?" + Request.QueryString.ToString());
 
    }
}