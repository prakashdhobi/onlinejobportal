﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;




public partial class Feedback : System.Web.UI.Page
{
    public SqlConnection con = new SqlConnection(@"Data Source=LAPTOP-G1HVDOBG ;Initial Catalog=project11;Integrated Security=True");

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Btnfeed_Click(object sender, EventArgs e)
    {
         try
            {
                lblerror.Text = "";
                lblmsg.Text = "";
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
                con.Open();
                string s = "insert into tblFeedback(Name,Email,Subject,Comment) values('" + txtfName.Text.Trim() + "','" + txtfEmail.Text.Trim() + "','" + txtfSubject.Text.Trim() + "','" + txtfComment.Text.Trim() + "' )";
                SqlCommand cmd = new SqlCommand(s, con);
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    clear();
                    lblmsg.Text = "FeedBack  SuccessFully";
                }
                else
                {
                    lblerror.Text = "FeedBack  is Not SuccessFull";
                }
                con.Close();
            }
            catch (Exception ex)
            {
                lblerror.Text = ex.Message;
            }
        }

        public void clear()
        {
            txtfName.Text = "";
            txtfEmail.Text = "";
            txtfSubject.Text = "";
            txtfComment.Text = "";
        }
    }
